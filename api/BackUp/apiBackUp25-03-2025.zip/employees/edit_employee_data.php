<?php

include '../connect.php';

header('Content-Type: application/json');

// Read JSON input correctly
$json = file_get_contents("php://input");
$data = json_decode($json, true);

// Debugging: Check if JSON decoding worked
if (!$data) {
    echo json_encode(["status" => "error", "message" => "Invalid JSON input"]);
    exit;
}

// Check required keys
if (!isset($data["editfor"]) || !isset($data["id"])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Proceed with normal script execution
$editfor = $data["editfor"];
$identifier_id = $data["id"];

// echo json_encode(["status" => "success", "message" => "Data received correctly"]);

// Determine column name based on 'editfor'
if ($editfor === 'pending') {
    $identifier_name = 'id';
    $message = "Updated Employee details from pending list";
} elseif ($editfor === 'registered') {
    $identifier_name = 'employee_id';
    $message = "$identifier_id details have been updated from registered list";
} else {
    echo json_encode(["status" => "error", "message" => "Invalid edit category: " . $editfor]);
    exit;
}

// Fetch other form data safely
$name = $data['name'] ?? null;
$birth_date = $data['birth_date'] ?? null;
$country_cd = $data['country_cd'] ?? null;
$contact = $data['contact'] ?? null;
$email = $data['email'] ?? null;
$address = $data['address'] ?? null;
$gender = $data['gender'] ?? null;
$joining_date = $data['joining_date'] ?? null;
$department = $data['department'] ?? null;
$designation = $data['designation'] ?? null;
$zone = $data['zone'] ?? null;
$branch = $data['branch'] ?? null;
$reporting_manager = $data['reporting_manager'] ?? null;
$profile_pic = $data['profile_pic'] ?? null;
$id_proof = $data['id_proof'] ?? null;
$bank_details = $data['bank_details'] ?? null;

// Determine user_type based on designation
$user_type = ($designation == '1') ? '24' : (($designation == '2') ? '25' : null);

// Ensure user_type is set
if ($user_type === null) {
    echo json_encode(["status" => "error", "message" => "Invalid designation"]);
    exit;
}

// Update employee details query
$sql = "UPDATE employees SET 
            name = :name, 
            date_of_birth = :date_of_birth, 
            country_code = :country_code, 
            contact = :contact, 
            email = :email, 
            address = :address, 
            gender = :gender, 
            date_of_joining = :date_of_joining, 
            department = :department, 
            designation = :designation, 
            zone = :zone, 
            branch = :branch, 
            reporting_manager = :reporting_manager, 
            profile_pic = :profile_pic, 
            id_proof = :id_proof, 
            bank_details = :bank_details, 
            user_type = :user_type 
        WHERE $identifier_name = :identifier_id";

$stmt = $conn->prepare($sql);
$result = $stmt->execute([
    ':name' => $name,
    ':date_of_birth' => $birth_date,
    ':country_code' => $country_cd,
    ':contact' => $contact,
    ':email' => $email,
    ':address' => $address,
    ':gender' => $gender,
    ':date_of_joining' => $joining_date,
    ':department' => $department,
    ':designation' => $designation,
    ':zone' => $zone,
    ':branch' => $branch,
    ':reporting_manager' => $reporting_manager,
    ':profile_pic' => $profile_pic,
    ':id_proof' => $id_proof,
    ':bank_details' => $bank_details,
    ':user_type' => $user_type,
    ':identifier_id' => $identifier_id
]);

// Response
if ($result) {
    echo json_encode(["status" => "success", "message" => $message]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update employee details"]);
}

?>