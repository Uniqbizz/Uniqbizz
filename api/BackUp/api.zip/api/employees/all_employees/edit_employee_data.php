<?php

include '../../connect.php';

header('Content-Type: application/json');

// Read JSON input correctly
$json = file_get_contents("php://input");
$data = json_decode($json, true);

// Debugging: Check if JSON decoding worked
if (!$data) {
    echo json_encode(["status" => "error", "message" => "Invalid JSON input"]);
    exit;
}

// Check required keys
if (!isset($data["editfor"]) || !isset($data["id"])) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Proceed with normal script execution
$editfor = $data["editfor"];

if($editfor == 'pending'){
    $identifier_id= $data["id"];
    $identifier_name = 'id=';
    $message="Updated Employee details from ".$editfor. " list";
    $message2="Updated Employee details from ".$editfor. " list";
}else if($editfor == 'registered') {
    $identifier_id= $data["id"];
    $identifier_name = 'employee_id=';
    $message=$identifier_id. " Details has been updated from ".$editfor. " list";
    $message2=$identifier_id. " Details has been updated from ".$editfor. " list";
}

// $id = $_POST['id'];
$name = $data['name'];
$birth_date = $data['birth_date'];
$country_cd = $data['country_cd'];
$contact = $data['contact'];
$email = $data['email'];
$address = $data['address'];
$gender = $data['gender'];
$joining_date = $data['joining_date'];
$department = $data['department'];
$designation = $data['designation'];
$zone = $data['zone'];
$branch = $data['branch'];
$reporting_manager = $data['reporting_manager'];
$profile_pic = $data['profile_pic'];
$id_proof = $data['id_proof'];
$bank_details = $data['bank_details'];

if($designation == '1'){
    $user_type = '24'; //BCM
}else if($designation == '2'){
    $user_type = '25'; //BDM
}

// Update employee details query
$sql = "UPDATE employees SET name = :name, date_of_birth = :date_of_birth, country_code = :country_code, contact = :contact, email = :email, address = :address, gender =:gender, date_of_joining = :date_of_joining, department = :department, designation = :designation, zone = :zone, branch = :branch, reporting_manager = :reporting_manager, profile_pic = :profile_pic, id_proof = :id_proof, bank_details = :bank_details, user_type = :user_type WHERE $identifier_name:identifier_id";
    $stmt = $conn->prepare($sql);
    $result = $stmt->execute(array(
        ':name' => $name,
        ':date_of_birth' => $birth_date,
        ':country_code' => $country_cd,
        ':contact' => $contact,
        ':email' => $email,
        ':address' => $address,
        ':gender' => $gender,
        ':date_of_joining' => $joining_date,
        ':department' => $department,
        ':designation' => $designation,
        ':zone' => $zone,
        ':branch' => $branch,
        ':reporting_manager' => $reporting_manager,
        ':profile_pic' => $profile_pic,
        ':id_proof' => $id_proof,
        ':bank_details' => $bank_details,
        // ':register_by' => $register_by,
        ':user_type' => $user_type,
        // ':status' => $status,
        ':identifier_id' => $identifier_id	
    ));

// Response
if ($result) {
    echo json_encode(["status" => "success", "message" => "Employee details updated successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to update employee details"]);
}

?>
