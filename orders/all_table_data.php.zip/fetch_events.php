<?php
require '../connect.php';
header('Content-Type: application/json');

try {
    // === 1️⃣ Parse JSON Request ===
    $request = json_decode(file_get_contents('php://input'), true);

    $userId = $request['userId'] ?? null;
    $userType = $request['userType'] ?? null;
    $selected_date = $request['selected_date'] ?? null;

    if (!$userId || !$userType) {
        echo json_encode(["error" => "Missing required parameters: userId or userType"]);
        exit;
    }

    // ✅ Convert selected_date to valid MySQL DATE (Y-m-d)
    if (!empty($selected_date)) {
        try {
            $dateObj = new DateTime($selected_date);
            $selected_date = $dateObj->format('Y-m-d');
        } catch (Exception $e) {
            echo json_encode(["error" => "Invalid selected_date format"]);
            exit;
        }
    }

    // === 2️⃣ Build TA Access Query Based on User Type ===
    $sql0 = '';
    $params = [':userId' => $userId];

    switch ($userType) {
        case '24': // BCM
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN employees bcm ON bcm.employee_id = :userId AND bcm.status = 1
                     WHERE ca.status = 1";
            break;

        case '25': // BDM
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN employees bdm ON bdm.employee_id = :userId AND bdm.status = 1
                     WHERE ca.status = 1";
            break;

        case '26': // BM
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     WHERE ca.status = 1 AND ca.reference_no = :userId";
            break;

        case '28': // MF
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN master_franchisee mf ON mf.master_franchisee_id = ca.reference_no
                     WHERE ca.status = 1 AND mf.master_franchisee_id = :userId";
            break;

        case '30': // SF
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN sub_franchisee f ON f.sub_franchisee_id = ca.reference_no
                     INNER JOIN sponsor_franchisee sf ON sf.sponsor_franchisee_id = f.reference_no
                     WHERE ca.status = 1 AND sf.sponsor_franchisee_id = :userId";
            break;

        case '29': // F
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN sub_franchisee f ON f.sub_franchisee_id = ca.reference_no
                     WHERE ca.status = 1 AND f.sub_franchisee_id = :userId";
            break;

        case '16': // TE
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN corporate_agency co ON co.corporate_agency_id = ca.reference_no
                     WHERE ca.status = 1 AND co.corporate_agency_id = :userId";
            break;

        case '11': // TC
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     WHERE ca.status = 1 AND ca.ca_travelagency_id = :userId";
            break;

        case '10': // Customer
            $sql0 = "SELECT ca.ca_travelagency_id FROM ca_travelagency ca
                     INNER JOIN ca_customer ccu ON ccu.ta_reference_no = ca.ca_travelagency_id
                     WHERE ca.status = 1 AND ccu.ca_customer_id = :userId";
            break;

        default:
            echo json_encode(["error" => "Invalid userType"]);
            exit;
    }

    // === 3️⃣ Execute TA Access Query ===
    $stmt0 = $conn->prepare($sql0);
    $stmt0->execute([':userId' => $userId]);
    $ta_list = $stmt0->fetchAll(PDO::FETCH_COLUMN);

    if (empty($ta_list)) {
        echo json_encode([ "success" => false,"bookings" => []], JSON_PRETTY_PRINT);
        exit;
    }

    // === 4️⃣ Build Optimized Query with GROUP BY for distinct events ===
    $placeholders = implode(',', array_fill(0, count($ta_list), '?'));
    $sql = "
        SELECT 
            b.date,
            GROUP_CONCAT(DISTINCT b.order_id ORDER BY b.date DESC) AS order_ids,
            GROUP_CONCAT(DISTINCT b.package_id ORDER BY b.date DESC) AS package_ids,
            COUNT(DISTINCT b.id) AS booking_count,
            GROUP_CONCAT(DISTINCT b.name ORDER BY b.date DESC SEPARATOR '||') AS customer_names,
            GROUP_CONCAT(DISTINCT b.status ORDER BY b.date DESC) AS statuses,
            GROUP_CONCAT(DISTINCT b.confirm_status ORDER BY b.date DESC) AS confirm_statuses,
            GROUP_CONCAT(DISTINCT p.name ORDER BY b.date DESC SEPARATOR '||') AS package_names,
            GROUP_CONCAT(DISTINCT p.tour_days ORDER BY b.date DESC) AS tour_days_list,
            GROUP_CONCAT(DISTINCT 
                (SELECT image FROM package_pictures WHERE package_id = b.package_id LIMIT 1) 
                ORDER BY b.date DESC SEPARATOR '||'
            ) AS package_images,
            GROUP_CONCAT(DISTINCT c.profile_pic ORDER BY b.date DESC SEPARATOR '||') AS customer_profile_pics,
            MIN(b.date) as first_booking_date,
            MAX(b.date) as last_booking_date
        FROM bookings b
        LEFT JOIN package p ON b.package_id = p.id
        LEFT JOIN ca_customer c ON b.customer_id = c.ca_customer_id
        WHERE b.customer_id IN (
            SELECT ca_customer_id FROM ca_customer WHERE ta_reference_no IN ($placeholders)
        )
    ";

    $bindParams = $ta_list;

    // ✅ Filter by specific date if provided
    if (!empty($selected_date)) {
        $sql .= " AND b.date = ?";
        $bindParams[] = $selected_date;
    }

    // Group by date to get all bookings for each date
    $sql .= " GROUP BY b.date ORDER BY b.date DESC";

    // === 5️⃣ Execute Query ===
    $stmt = $conn->prepare($sql);
    $stmt->execute($bindParams);
    $dateGroups = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // === 6️⃣ Process Results into Calendar Events ===
    $events = [];
    
    foreach ($dateGroups as $group) {
        $date = $group['date'];
        $bookingCount = $group['booking_count'];
        
        // Split concatenated values
        $orderIds = explode(',', $group['order_ids']);
        $packageNames = explode('||', $group['package_names']);
        $customerNames = explode('||', $group['customer_names']);
        $packageImages = explode('||', $group['package_images']);
        $profilePics = explode('||', $group['customer_profile_pics']);
        
        // Create events based on booking count
        if ($bookingCount == 1) {
            // Single booking on this date
            $events[] = [
                "title" => $packageNames[0] ?: "Booking",
                "start" => $date,
                "extendedProps" => [
                    "order_id" => $orderIds[0],
                    "customer_name" => $customerNames[0],
                    "status" => $group['statuses'],
                    "confirm_status" => $group['confirm_statuses'],
                    "package_image" => $packageImages[0] ?? null,
                    "profile_pic" => $profilePics[0] ?? null,
                    "package_name" => $packageNames[0]
                ]
            ];
        } else {
            // Multiple bookings on same date - create a summary event
            $events[] = [
                "title" => "$bookingCount Bookings",
                "start" => $date,
                "backgroundColor" => "#3498db",
                "extendedProps" => [
                    "multiple" => true,
                    "booking_count" => $bookingCount,
                    "first_order_id" => $orderIds[0],
                    "first_customer" => $customerNames[0],
                    "all_orders" => $orderIds,
                    "all_customers" => $customerNames,
                    "date" => $date
                ]
            ];
        }
    }

    // === 7️⃣ Format JSON Response ===
    echo json_encode([
        "success" => true,
        "bookings" => $events ?: []
    ], JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "error" => "Database error: " . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}